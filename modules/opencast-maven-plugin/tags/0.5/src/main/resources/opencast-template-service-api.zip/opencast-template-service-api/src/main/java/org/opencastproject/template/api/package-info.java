/**
 * Template service.
 */
package org.opencastproject.template.api;
