/**
 *  Copyright 2009 The Regents of the University of California
 *  Licensed under the Educational Community License, Version 2.0
 *  (the "License"); you may not use this file except in compliance
 *  with the License. You may obtain a copy of the License at
 *
 *  http://www.osedu.org/licenses/ECL-2.0
 *
 *  Unless required by applicable law or agreed to in writing,
 *  software distributed under the License is distributed on an "AS IS"
 *  BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express
 *  or implied. See the License for the specific language governing
 *  permissions and limitations under the License.
 *
 */
package org.opencastproject.template.endpoint;

import org.opencastproject.template.api.TemplateEntity;
import org.opencastproject.template.api.TemplateService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;

/**
 * @see TemplateWebService
 */
@WebService()
public class TemplateWebServiceImpl implements TemplateWebService {
  private static final Logger logger = LoggerFactory.getLogger(TemplateWebServiceImpl.class);
  
  private TemplateService service;
  public void setService(TemplateService service) {
    this.service = service;
  }
  
  @WebMethod()
  @WebResult(name="template-entity")
  public TemplateEntityJaxbImpl getTemplateEntity(@WebParam(name="id") String id) {
    TemplateEntity entity = service.getTemplateEntity(id);
    return new TemplateEntityJaxbImpl(entity);
  }

  @WebMethod()
  public void storeTemplateEntity(@WebParam(name="template-entity") TemplateEntityJaxbImpl jaxbEntity) {
    logger.info("Storing " + jaxbEntity);
    service.saveTemplateEntity(jaxbEntity.getEntity());
  }
}
