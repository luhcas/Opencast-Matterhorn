/**
 * Template REST and WSDL Service endpoints
 */
@XmlSchema(elementFormDefault=XmlNsForm.QUALIFIED, attributeFormDefault=XmlNsForm.QUALIFIED)
package org.opencastproject.template.endpoint;

import javax.xml.bind.annotation.XmlSchema;
import javax.xml.bind.annotation.XmlNsForm;
