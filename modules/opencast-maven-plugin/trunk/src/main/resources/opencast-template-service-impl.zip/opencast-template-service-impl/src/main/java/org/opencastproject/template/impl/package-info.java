/**
 * Template service implementation classes
 */
@javax.xml.bind.annotation.XmlSchema(elementFormDefault=XmlNsForm.QUALIFIED)
package org.opencastproject.template.impl;

import javax.xml.bind.annotation.XmlNsForm;
